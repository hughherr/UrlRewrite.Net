package com.nimbusds.jose.shaded.jcip;

/**
 * Placeholder to avoid {@link java.lang.NoClassDefFoundError} after shading.
 */
interface Placeholder {
}
