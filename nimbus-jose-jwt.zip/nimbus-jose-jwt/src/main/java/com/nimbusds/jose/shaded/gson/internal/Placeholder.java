package com.nimbusds.jose.shaded.gson.internal;

/**
 * Placeholder in order for module-info to know about this package, which will be shaded.
 */
interface Placeholder {
}
