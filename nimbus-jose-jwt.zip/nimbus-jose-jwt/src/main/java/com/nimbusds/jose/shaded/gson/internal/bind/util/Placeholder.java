package com.nimbusds.jose.shaded.gson.internal.bind.util;

/**
 * Placeholder to avoid {@link java.lang.NoClassDefFoundError} after shading.
 */
interface Placeholder {
}
