package com.nimbusds.jose.shaded.gson.reflect;

/**
 * Placeholder to avoid {@link java.lang.NoClassDefFoundError} after shading.
 */
interface Placeholder {
}
