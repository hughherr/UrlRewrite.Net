package com.nimbusds.jose.shaded.gson.stream;

/**
 * Placeholder to avoid {@link java.lang.NoClassDefFoundError} after shading.
 */
interface Placeholder {
}
