package com.nimbusds.jose.shaded.gson.internal.reflect;

/**
 * Placeholder to avoid {@link java.lang.NoClassDefFoundError} after shading.
 */
interface Placeholder {
}
