/*
 * nimbus-jose-jwt
 *
 * Copyright 2012-2016, Connect2id Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.jose.crypto;


import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Provider;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.*;
import java.util.Collections;
import java.util.HashSet;

import com.nimbusds.jose.crypto.bc.BouncyCastleProviderSingleton;
import com.nimbusds.jose.crypto.opts.UserAuthenticationRequired;
import com.nimbusds.jwt.JWTClaimNames;
import junit.framework.TestCase;

import com.nimbusds.jose.*;
import com.nimbusds.jose.jwk.Curve;
import com.nimbusds.jose.jwk.ECKey;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.gen.ECKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;


/**
 * Tests round-trip ES256, ES256K, ES384 and ES512 JWS signing and
 * verification.
 *
 * @author Vladimir Dzhuvinov
 * @version 2024-05-08
 */
public class ECDSARoundTripTest extends TestCase {


	private static final int COFACTOR = 1;


	public static final ECParameterSpec EC256SPEC = new ECParameterSpec(
		new EllipticCurve(
			new ECFieldFp(new BigInteger("115792089210356248762697446949407573530086143415290314195533631308867097853951")),
			new BigInteger("115792089210356248762697446949407573530086143415290314195533631308867097853948"),
			new BigInteger("41058363725152142129326129780047268409114441015993725554835256314039467401291")),
		new ECPoint(
			new BigInteger("48439561293906451759052585252797914202762949526041747995844080717082404635286"),
			new BigInteger("36134250956749795798585127919587881956611106672985015071877198253568414405109")),
		new BigInteger("115792089210356248762697446949407573529996955224135760342422259061068512044369"),
		COFACTOR);


	public static final ECParameterSpec EC256KSPEC = new ECParameterSpec(
			new EllipticCurve(
					new ECFieldFp(new BigInteger("115792089237316195423570985008687907853269984665640564039457584007908834671663")),
					new BigInteger("0"),
					new BigInteger("7")),
			new ECPoint(
					new BigInteger("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
					new BigInteger("32670510020758816978083085130507043184471273380659243275938904335757337482424")),
			new BigInteger("115792089237316195423570985008687907852837564279074904382605163141518161494337"),
			1);


	public static final ECParameterSpec EC384SPEC = new ECParameterSpec(
		new EllipticCurve(
			new ECFieldFp(new BigInteger("39402006196394479212279040100143613805079739270465" +
				                     "44666794829340424572177149687032904726608825893800" +
				                     "1861606973112319")),
			new BigInteger("39402006196394479212279040100143613805079739270465" +
				       "44666794829340424572177149687032904726608825893800" +
				       "1861606973112316"),
			new BigInteger("27580193559959705877849011840389048093056905856361" +
				       "56852142870730198868924130986086513626076488374510" +
				       "7765439761230575")
        		),
		new ECPoint(
			new BigInteger("26247035095799689268623156744566981891852923491109" +
				       "21338781561590092551885473805008902238805397571978" +
				       "6650872476732087"),
			new BigInteger("83257109614890299855467512895201081792878530488613" +
				       "15594709205902480503199884419224438643760392947333" +
				       "078086511627871")
			),
		new BigInteger("39402006196394479212279040100143613805079739270465446667946905279627" +
		               "659399113263569398956308152294913554433653942643"),
		COFACTOR);


	public static final ECParameterSpec EC512SPEC = new ECParameterSpec(
		new EllipticCurve(
			new ECFieldFp(new BigInteger("68647976601306097149819007990813932172694353001433" +
				                     "05409394463459185543183397656052122559640661454554" +
				                     "97729631139148085803712198799971664381257402829111" +
				                     "5057151")),
			new BigInteger("68647976601306097149819007990813932172694353001433" +
				       "05409394463459185543183397656052122559640661454554" +
				       "97729631139148085803712198799971664381257402829111" +
				       "5057148"),
			new BigInteger("10938490380737342745111123907668055699362075989516" +
				       "83748994586394495953116150735016013708737573759623" +
				       "24859213229670631330943845253159101291214232748847" +
				       "8985984")
			),
		new ECPoint(
			new BigInteger("26617408020502170632287687167233609607298591687569" +
				       "73147706671368418802944996427808491545080627771902" +
				       "35209424122506555866215711354557091681416163731589" +
				       "5999846"),
			new BigInteger("37571800257700204635455072244911836035944551347697" +
				       "62486694567779615544477440556316691234405012945539" +
				       "56214444453728942852258566672919658081012434427757" +
				       "8376784")
			),
		new BigInteger("68647976601306097149819007990813932172694353001433" +
                               "05409394463459185543183397655394245057746333217197" +
                               "53296399637136332111386476861244038034037280889270" +
                               "7005449"),
		COFACTOR);


	public static KeyPair createECKeyPair(final AlgorithmParameterSpec spec)
		throws Exception {

		return createECKeyPair(spec, null);
	}


	public static KeyPair createECKeyPair(final AlgorithmParameterSpec spec, final Provider provider)
		throws Exception {

		// Create the public and private keys
		KeyPairGenerator keyGenerator;
		if (provider == null) {
			keyGenerator = KeyPairGenerator.getInstance("EC");
		} else {
			keyGenerator = KeyPairGenerator.getInstance("EC", provider);
		}
		keyGenerator.initialize(spec);
		return keyGenerator.generateKeyPair();
	}


	public static JWSObject createInitialJWSObject(final JWSAlgorithm alg) {

		JWSHeader header = new JWSHeader.Builder(alg).
			contentType("text/plain").
			build();

		return new JWSObject(header, new Payload("Hello world!"));
	}


	public void testES256()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC256SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES256);

		// Initialise signer
		JWSSigner signer = new ECDSASigner(privateKey);

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		JWSVerifier verifier = new ECDSAVerifier(publicKey);

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC256 signature verified", verified);
	}


	public void testES256K()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC256KSPEC, BouncyCastleProviderSingleton.getInstance());
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES256K);

		// Initialise signer
		JWSSigner signer = new ECDSASigner(privateKey);
		signer.getJCAContext().setProvider(BouncyCastleProviderSingleton.getInstance());

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		JWSVerifier verifier = new ECDSAVerifier(publicKey);
		verifier.getJCAContext().setProvider(BouncyCastleProviderSingleton.getInstance());

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC256K signature verified", verified);
	}


	public void testES384()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC384SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES384);

		// Initialise signer
		JWSSigner signer = new ECDSASigner(privateKey);

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		JWSVerifier verifier = new ECDSAVerifier(publicKey);

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC384 signature verified", verified);
	}


	public void testES512()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC512SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES512);

		// Initialise signer
		JWSSigner signer = new ECDSASigner(privateKey);

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		JWSVerifier verifier = new ECDSAVerifier(publicKey);

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC512 signature verified", verified);
	}


	public void testECKeyConstructors()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC256SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES256);

		// Initialise signer
		ECDSASigner signer = new ECDSASigner(privateKey);
		assertEquals(privateKey, signer.getPrivateKey());

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		ECDSAVerifier verifier = new ECDSAVerifier(publicKey);
		assertEquals(publicKey, verifier.getPublicKey());

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC256 signature verified", verified);
	}

	public void testECKeyUserVerificationOption()
			throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC256SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES256);

		// Initialise signer
		ECDSASigner signer = new ECDSASigner(
				privateKey,
				new HashSet<JWSSignerOption>(){{
					this.add(UserAuthenticationRequired.getInstance());
				}} );
		assertEquals(privateKey, signer.getPrivateKey());

		boolean signingInterrupted;
		try {
			jwsObject.sign(signer);
			signingInterrupted = false;
		} catch (ActionRequiredForJWSCompletionException e) {
			signingInterrupted = true;
			
			assertEquals("Authenticate user to complete signing", e.getMessage());
			assertEquals(UserAuthenticationRequired.getInstance(), e.getTriggeringOption());
			assertEquals("UserAuthenticationRequired", e.getTriggeringOption().toString());
			assertNotNull(e.getCompletableJWSObjectSigning());
			assertNotNull(e.getCompletableJWSObjectSigning().getInitializedSignature());
			
			// Perform user authentication to unlock the private key,
			// e.g. with biometric prompt
			// ...
			
			// Complete the signing after the key is unlocked
			e.getCompletableJWSObjectSigning().complete();
		}

		assertTrue(signingInterrupted);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		ECDSAVerifier verifier = new ECDSAVerifier(publicKey);
		assertEquals(publicKey, verifier.getPublicKey());

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC256 signature verified", verified);
	}


	public void testECJWKConstructors()
		throws Exception {

		// Create the public and private keys
		KeyPair keyPair = createECKeyPair(EC256SPEC);
		ECKey ecJWK = new ECKey.Builder(Curve.P_256, (ECPublicKey) keyPair.getPublic()).
			privateKey((ECPrivateKey) keyPair.getPrivate()).
			build();

		// Creates initial unsigned JWS object
		JWSObject jwsObject = createInitialJWSObject(JWSAlgorithm.ES256);

		// Initialise signer
		ECDSASigner signer = new ECDSASigner(ecJWK);
		assertEquals(ecJWK.getD().decodeToBigInteger(), ((ECPrivateKey)signer.getPrivateKey()).getS());

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		// Initialise verifier
		ECDSAVerifier verifier = new ECDSAVerifier(ecJWK);
		assertEquals(ecJWK.getX().decodeToBigInteger(), verifier.getPublicKey().getW().getAffineX());
		assertEquals(ecJWK.getY().decodeToBigInteger(), verifier.getPublicKey().getW().getAffineY());

		boolean verified = jwsObject.verify(verifier);

		assertTrue("EC256 signature verified", verified);
	}


	public void testCritHeaderParamIgnore()
		throws Exception {

		JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.ES512).
			customParam(JWTClaimNames.EXPIRATION_TIME, "2014-04-24").
			criticalParams(new HashSet<>(Collections.singletonList(JWTClaimNames.EXPIRATION_TIME))).
			build();

		KeyPair keyPair = createECKeyPair(EC512SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		JWSObject jwsObject = new JWSObject(header, new Payload("Hello world!"));

		JWSSigner signer = new ECDSASigner(privateKey);

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		JWSVerifier verifier = new ECDSAVerifier(publicKey, new HashSet<>(Collections.singletonList(JWTClaimNames.EXPIRATION_TIME)));

		boolean verified = jwsObject.verify(verifier);

		assertTrue("Verified signature", verified);

		assertEquals("State check", JWSObject.State.VERIFIED, jwsObject.getState());
	}


	public void testCritHeaderParamReject()
		throws Exception {

		JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.ES512).
			customParam(JWTClaimNames.EXPIRATION_TIME, "2014-04-24").
			criticalParams(new HashSet<>(Collections.singletonList(JWTClaimNames.EXPIRATION_TIME))).
			build();

		KeyPair keyPair = createECKeyPair(EC512SPEC);
		ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
		ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();

		JWSObject jwsObject = new JWSObject(header, new Payload("Hello world!"));

		JWSSigner signer = new ECDSASigner(privateKey);

		jwsObject.sign(signer);

		assertEquals(JWSObject.State.SIGNED, jwsObject.getState());

		JWSVerifier verifier = new ECDSAVerifier(publicKey);

		boolean verified = jwsObject.verify(verifier);

		assertFalse("Verified signature", verified);

		assertEquals("State check", JWSObject.State.SIGNED, jwsObject.getState());
	}
	
	
	public void testES256KWithGen()
		throws Exception {

		// Generate EC key pair on the secp256k1 curve
		ECKey ecJWK = new ECKeyGenerator(Curve.SECP256K1)
			.keyUse(KeyUse.SIGNATURE)
			.keyID("123")
			.provider(BouncyCastleProviderSingleton.getInstance())
			.generate();
		
		ECKey ecPublicJWK = ecJWK.toPublicJWK();
		
		JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
			.subject("alice")
			.build();
		
		SignedJWT jwt = new SignedJWT(
			new JWSHeader.Builder(JWSAlgorithm.ES256K)
				.keyID(ecJWK.getKeyID())
				.build(),
			claimsSet);
		
		JWSSigner signer = new ECDSASigner(ecJWK);
		signer.getJCAContext().setProvider(BouncyCastleProviderSingleton.getInstance());
		jwt.sign(signer);
		
		String out = jwt.serialize();
		
//		System.out.println(out);
		
		jwt = SignedJWT.parse(out);
		
		JWSVerifier verifier = new ECDSAVerifier(ecPublicJWK);
		verifier.getJCAContext().setProvider(BouncyCastleProviderSingleton.getInstance());
		assertTrue(jwt.verify(verifier));
		
		assertEquals("alice", jwt.getJWTClaimsSet().getSubject());
	}
}
