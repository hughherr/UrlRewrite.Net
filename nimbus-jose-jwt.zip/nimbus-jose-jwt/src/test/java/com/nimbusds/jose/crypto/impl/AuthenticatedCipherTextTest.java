/*
 * nimbus-jose-jwt
 *
 * Copyright 2012-2016, Connect2id Ltd and contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed
 * under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.nimbusds.jose.crypto.impl;


import com.nimbusds.jose.crypto.impl.AuthenticatedCipherText;
import junit.framework.TestCase;

import org.junit.Assert;


/**
 * Tests the authenticated cipher text wrapper.
 *
 * @author Vladimir Dzhuvinov
 * @version 2013-05-07
 */
public class AuthenticatedCipherTextTest extends TestCase {


	public void testRun() {

		byte[] cipherText = {1, 2, 3, 4, 5};
		byte[] authTag = {6, 7, 8, 9, 10};

		AuthenticatedCipherText act = new AuthenticatedCipherText(cipherText, authTag);

		Assert.assertArrayEquals(cipherText, act.getCipherText());

		Assert.assertArrayEquals(authTag, act.getAuthenticationTag());
	}
}