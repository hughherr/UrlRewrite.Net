insert into L649_COUNT
select 11 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=1) as L_COUNT from L649_COUNT where L_SELECT=1

insert into L649_COUNT
select 21 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=2) as L_COUNT from L649_COUNT where L_SELECT=2

insert into L649_COUNT
select 31 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=3) as L_COUNT from L649_COUNT where L_SELECT=3

insert into L649_COUNT
select 41 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=4) as L_COUNT from L649_COUNT where L_SELECT=4

insert into L649_COUNT
select 51 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=5) as L_COUNT from L649_COUNT where L_SELECT=5

insert into L649_COUNT
select 61 as L_SELECT, 'AVG' as L_VALUE, sum(L_COUNT)/(select count(*) from L649_COUNT where L_SELECT=6) as L_COUNT from L649_COUNT where L_SELECT=6

select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N5 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_NUMBER where L_SEQNO in (select L_SEQNO from L649_GUESS) 
)
