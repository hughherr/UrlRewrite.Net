select * from L649_COUNT where L_SELECT='1' and L_VALUE in 
(
select L_N1 from L649_GUESS
union
select L_N2 from L649_GUESS
)