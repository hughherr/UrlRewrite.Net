BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `L649_NUMBER_STAT` (
	`L_SEQNO`	TEXT,
	`L_DATE`	TEXT,
	`L_LEVEL`	TEXT,
	`L_NX`	TEXT
);
COMMIT;


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N1 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N2 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N3 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 1 as L_LEVEL, L_N6 as LN from L649_NUMBER
) a 


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N1 || ',' || L_N2 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N1 || ',' || L_N3 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N1 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N1 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N1 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N2 || ',' || L_N3 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N2 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N2 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N2 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N3 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N3 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N3 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 2 as L_LEVEL, L_N5 || ',' || L_N6 as LN from L649_NUMBER
) a 


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N1 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N2 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N3 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N3 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N3 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 3 as L_LEVEL, L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
) a 


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N1 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N2 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 4 as L_LEVEL, L_N3 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
) a 


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N1 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
union all
select L_SEQNO, L_DATE, 5 as L_LEVEL, L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
) a 


INSERT INTO L649_NUMBER_STAT
SELECT * FROM
(
select L_SEQNO, L_DATE, 6 as L_LEVEL, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 || ',' || L_N6 as LN from L649_NUMBER
) a



select * from L649_NUMBER_STAT where L_NX='05' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='05,08' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='05,08,13' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='05,08,13,17' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='05,08,13,17,29' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='05,08,13,17,29,38' and L_SEQNO > '0001' order by L_SEQNO

select * from L649_NUMBER_STAT where L_NX='12' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='12,14' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='12,14,32' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='12,14,32,34' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='12,14,32,34,40' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='12,14,32,34,40,48' and L_SEQNO > '0001' order by L_SEQNO

12 	14 	32 	34 	40 	48 	

select * from L649_NUMBER_STAT where L_NX='14' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='14,20' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='14,20,23' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='14,20,23,33' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='14,20,23,33,34' and L_SEQNO > '0001' order by L_SEQNO
select * from L649_NUMBER_STAT where L_NX='14,20,23,33,34,40' and L_SEQNO > '0001' order by L_SEQNO

14 	20 	23 	33 	34 	40 	24