import java.util.List;

public class HelloWorld {
	
	enum PType {
		SUN, MON, TUE
	}

	public static void main(String[] argv) {
		System.out.println(PType.SUN);
		System.exit(0);
	}
	
	public static <T> void fill (List<T> list, T val) {
		for (int i=0; i < list.size(); i++) 
			list.set(i,  val);
	}
}
