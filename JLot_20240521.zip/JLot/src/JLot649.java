import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.sql.Connection;

public class JLot649
{
	public static boolean isNumeric(String strNum) {
	    if (strNum == null) {
	        return false;
	    }
	    try {
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	public static void main( String args[] )
	{
		Connection c = null;
		Statement stmt = null;
		try {
			//String game = "lto12"; // 539 496
			//String game = "539";
			String game = "496";
			String dataUrl = "";
			String sqlInsert = "";
			String table = "";
			int openNo = 0;
			//if (game == "539") {
			if (args[0].equals("539")) {
				System.out.println("539");
				dataUrl = "https://www.pilio.idv.tw/lto539/ServerA/list.asp";  // 539
				table = "L539_NUMBER";
				sqlInsert = "INSERT INTO L539_NUMBER (L_SEQNO,L_DATE,L_N1,L_N2,L_N3,L_N4,L_N5) ";
				openNo = 5;
			}
			//else if (game == "lto12") {
			else if (args[0].equals("1224")) {
				System.out.println("1224");
				dataUrl = "https://www.pilio.idv.tw/lto12/ServerB/list.asp";  // ��Ĺ
				table = "L12_NUMBER";
				sqlInsert = "INSERT INTO L12_NUMBER (L_SEQNO,L_DATE,L_N1,L_N2,L_N3,L_N4,L_N5,L_N6,L_N7,L_N8,L_N9,L_N10,L_N11,L_N12) ";
				openNo = 12;				
			}
			else if (args[0].equals("649")) {
				System.out.println("649");
				dataUrl = "http://www.pilio.idv.tw/ltobig/list.asp"; // �j�ֳz
				table = "L649_NUMBER_BASE";
				sqlInsert = "INSERT INTO L649_NUMBER_BASE (L_SEQNO,L_DATE,L_N1,L_N2,L_N3,L_N4,L_N5,L_N6,L_N7) ";
				openNo = 6;
			}
			else if (args[0].equals("3star")) {
				System.out.println("3star");
				dataUrl = "https://www.pilio.idv.tw/lto/list3.asp"; // �j�ֳz
				table = "L3star_NUMBER";
				sqlInsert = "INSERT INTO L3star_NUMBER (L_SEQNO,L_DATE,L_N1,L_N2,L_N3) ";
				openNo = 3;
			}
			else if (args[0].equals("4star")) {
				System.out.println("4star");
				dataUrl = "https://www.pilio.idv.tw/lto/list4.asp"; // �j�ֳz
				table = "L4star_NUMBER";
				sqlInsert = "INSERT INTO L4star_NUMBER (L_SEQNO,L_DATE,L_N1,L_N2,L_N3,L_N4) ";
				openNo = 4;
			}			
			else if (args[0].equals("638")) {
				System.out.println("638");
				dataUrl = "https://www.pilio.idv.tw/lto/list.asp"; // �¤O�m
				table = "L638_NUMBER";
				sqlInsert = "INSERT INTO " + table + " (L_SEQNO,L_DATE,L_N1,L_N2,L_N3,L_N4,L_N5,L_N6, L_N7) ";
				openNo = 6;				
			}

			c = null;
			stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    String sql = "delete from " + table + ";"; 
	        stmt.executeUpdate(sql);	

			//Document doc = Jsoup.connect("https://en.wikipedia.org/wiki/Main_Page").get();
			//Elements newsHeadlines = doc.select("#mp-itn b a");
			Document doc = Jsoup.connect(dataUrl).timeout(60000).get();
			Elements links = doc.body().select("a[href]");
			int iLinkCount = 0;
			for (Element elm : links) {
				if (elm.text().contains("最末頁")) {
					String href = elm.attr("href");
					int iStart = href.indexOf("=") + 1;
					int iEnd = href.indexOf("&");
					iLinkCount = Integer.parseInt(href.substring(iStart, iEnd));
				}
			}
			ArrayList<String> al = new ArrayList<String>();
			for (int i=1; i<=iLinkCount; i++)
				al.add(dataUrl + "?indexpage=" + i + "&orderby=new");
			/*
			for (Element link : links) {
				if (link.attr("href").contains("list.asp?indexpage"))
				{
					if (!al.contains("http://www.pilio.idv.tw/ltobig/"+link.attr("href")))
					{
						al.add("http://www.pilio.idv.tw/ltobig/"+link.attr("href"));
						//System.out.println(link.attr("href"));
					}
				}
			} 
			*/
			int iSeq = 0;
			for(String link: al){
				System.out.println(link);
				doc = Jsoup.connect(link).timeout(60000).get();
				Elements newsHeadlines = doc.select("table");
				for (Element e : newsHeadlines) {
					Elements items = e.select("tr");
					//if(items.first().select("td").first().text().equals("���")) {
					//if(isNumeric(items.first().select("td").first().text())) {
						for (Element tr : items) {
							Elements data = tr.select("td");
							//if (data.get(0).text().equals("���"))
							if (data.get(0).text().length() < 10 || !isNumeric(data.get(0).text().substring(0,4)))
								continue;
							String seqno = "00000" + ++iSeq;
							if (isInteger(seqno)) {
								seqno = seqno.substring(seqno.length() - 4);
								String date = data.get(0).text();
								String number = data.get(1).text().replace((char)160, (char)32).replace(",","");
								//System.out.println(number);
								String[] numbers = number.split(" ");
								String special = "";
								if (data.size() > 2) {
									special = data.get(2).text().replace((char)160, (char)32).trim();
									if (!isInteger(special))
										special = "";
								}
								if (numbers.length < openNo)
									System.out.println(data.get(2).text());
								else {	
								      sql = sqlInsert + "VALUES ('"+seqno+"','"+date+"'";
								      for (int i=0; i<openNo; i++) {  
								    	  sql += ",'"+numbers[i]+"'";
								      } 
								      if (special == "")
								    	  sql += ");";
								      else
								    	  sql += ",'" + special + "');"; 
								      System.out.println(sql);
								      stmt.executeUpdate(sql);	
								}
								/*
								for (Element td : data) {
									System.out.println(td.text().toString());
								}
								*/
							}
						}
					//}
				}
			}
			/*
			Element body=doc.body().child(2);
			Elements links=body.select("a[href]");
			for (Iterator<Element> elementIterator=links.iterator(); elementIterator.hasNext(); ) {
				Element link=elementIterator.next();
				System.out.println(link.attr("href"));
			}
			*/
			/*
			Elements links = doc.select("a[href]");
			for (Element link : links) {
				System.out.println(link.attr("abs:href"));
			}
			*/
			/*
			Elements newsHeadlines = doc.select("table");
			for (Element e : newsHeadlines) {
				Elements items = e.select("tr");
				if(items.first().select("td").first().text().equals("����")) {
					for (Element tr : items) {
						System.out.println(tr.toString());
					}
				}
			}
			*/
			//System.out.println(newsHeadlines.toString());//
			BufferedReader reader;

			try {
			    sql = "delete from L649_NUMBER;"; 
		        stmt.executeUpdate(sql);
		        
			    sql = "insert into L649_NUMBER select * from L649_NUMBER_BASE where L_SEQNO != '0001';"; 
		        stmt.executeUpdate(sql);
		        
			    sql = "delete from L649_COUNT;"; 
		        stmt.executeUpdate(sql);	
				reader = new BufferedReader(new FileReader("L649_COUNT.sql"));
				String line = reader.readLine();
				sql = "";
				while (line != null) {
					line = line.trim();
					if (!line.equals(""))
					{
						if (line.equals("----------"))
						{
							stmt.executeUpdate(sql);
							sql = "";							
						}
						else
						{
							sql = sql + " " + line;
						}
					}
					// read next line
					line = reader.readLine();
				}

				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (stmt != null)
					stmt.close();
				if (c != null)
				{
				    c.commit();
				    c.close();
				}
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
		}
	    System.out.println("DONE!!");
	}
	
	public static boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
}

// select * from L649_NUMBER where L_N1 in (1,6,7,24,34,47) and L_N2 in (1,6,7,24,34,47) and L_N3 in (1,6,7,24,34,47) and L_N4 in (1,6,7,24,34,47)  and L_N5 in (1,6,7,24,34,47)  and L_N6 in (1,6,7,24,34,47)