import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;  
import java.io.File;  

public class JLotStat539 {
	public static void main( String args[] )
	{
		try {
			Connection c = null;
			Statement stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    //String sql = "select * from L539_NUMBER where L_SEQNO>='0002' and L_SEQNO<='0008';";
		    String sql = "delete from L539_COUNT;";
		    stmt.executeUpdate(sql);
		    sql = "delete from L539_NUMBER;";
		    stmt.executeUpdate(sql);
		    sql = "insert into L539_NUMBER select * from L539_NUMBER_BASE where L_SEQNO>'0001';";
		    stmt.executeUpdate(sql);

	        try   
	        {  
	        	//creating a constructor of file class and parsing an XML file  
	        	File file = new File("./L539_COUNT.xml");  
	        	//an instance of factory that gives a document builder  
	        	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
	        	//an instance of builder to parse the specified xml file  
	        	DocumentBuilder db = dbf.newDocumentBuilder();  
	        	Document doc = db.parse(file);  
	        	doc.getDocumentElement().normalize();  
	        	//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
	        	NodeList nodeList = doc.getElementsByTagName("SQLContent");  
	        	// nodeList is not iterable, so we are using for loop  
	        	for (int itr = 0; itr < nodeList.getLength(); itr++)   
	        	{  
	        		Node node = nodeList.item(itr);  
	        		System.out.println("\nNode Name :" + node.getNodeName());  
	        		if (node.getNodeType() == Node.ELEMENT_NODE)   
	        		{  
	        			sql = node.getTextContent();  
	        			System.out.println(sql);
	        			stmt.executeUpdate(sql);  
	        		}  
	        	}  
	        }   
	        catch (Exception e)   
	        {  
	        	e.printStackTrace();  
	        }  
	        //stmt.executeUpdate(sql);
	        stmt.close();
		    c.commit();
		    c.close();
		    System.out.println("Done");
   
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
