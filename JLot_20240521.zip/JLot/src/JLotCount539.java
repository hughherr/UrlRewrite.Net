import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.sql.Connection;

public class JLotCount539
{
	public static boolean isNumeric(String strNum) {
	    if (strNum == null) {
	        return false;
	    }
	    try {
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	public static void main( String args[] )
	{
		Connection c = null;
		Statement stmt = null;
		try {
			//String game = "lto12"; // 539 496
			String game = "539";
			//String game = "496";
			String dataUrl = "";
			String sqlInsert = "";
			String table = "";
			int openNo = 0;
			String sql = "";
			//System.out.println(newsHeadlines.toString());//
			BufferedReader reader;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();

			try {
			    sql = "delete from L539_NUMBER where L_DATE=(select L_DATE from L539_NUMBER order by L_SEQNO asc LIMIT 1);"; 
		        stmt.executeUpdate(sql);	
				reader = new BufferedReader(new FileReader("L539_COUNT_DATE.sql"));
				String line = reader.readLine();
				sql = "";
				while (line != null) {
					line = line.trim();
					if (!line.equals(""))
					{
						if (line.equals("----------"))
						{
							stmt.executeUpdate(sql);
							sql = "";							
						}
						else
						{
							sql = sql + " " + line;
						}
					}
					// read next line
					line = reader.readLine();
				}

				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (stmt != null)
					stmt.close();
				if (c != null)
				{
				    c.commit();
				    c.close();
				}
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
		}
	    System.out.println("DONE!!");
	}
	
	public static boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public static boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}
}

// select * from L649_NUMBER where L_N1 in (1,6,7,24,34,47) and L_N2 in (1,6,7,24,34,47) and L_N3 in (1,6,7,24,34,47) and L_N4 in (1,6,7,24,34,47)  and L_N5 in (1,6,7,24,34,47)  and L_N6 in (1,6,7,24,34,47)