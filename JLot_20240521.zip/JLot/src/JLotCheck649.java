import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;  
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;  

public class JLotCheck649 {
	
	public static String printNum(int [] number)
	{
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<number.length; i++)
		{
			sb.append(String.format("%02d\n", number[i]));
		}

		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				if (i<j)
					sb.append(String.format("%02d,%02d\n", number[i], number[j]));
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					if (i<j && j < k)
						sb.append(String.format("%02d,%02d,%02d\n", number[i], number[j], number[k]));
				}
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					for (int p=0; p<number.length; p++)
					{
						if (i<j && j < k && k<p)
							sb.append(String.format("%02d,%02d,%02d,%02d\n", number[i], number[j], number[k], number[p]));
					}
				}
			}
		}			
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					for (int p=0; p<number.length; p++)
					{
						for (int q=0; q<number.length; q++)
						{
							if (i<j && j < k && k<p && p<q)
								sb.append(String.format("%02d,%02d,%02d,%02d,%02d\n", number[i], number[j], number[k], number[p], number[q]));
						}				
					}
				}
			}
		}	
		
		sb.append(String.format("%02d,%02d,%02d,%02d,%02d,%02d", number[0], number[1], number[2], number[3], number[4], number[5]));
		return(sb.toString());
	}
	
	public static void main( String args[] )
	{
		try {
			//int [] lottoryNum = {1, 2, 6, 7, 27, 38};
			
			//int [] lottoryNum = {6, 19, 22, 25, 39, 42}; // 3
			//int [] lottoryNum = {2, 7, 9, 19, 43, 44}; // 4
			//int [] lottoryNum = {3, 4, 6, 15, 17, 39};  // 4
			//int [] lottoryNum = {1, 6, 22, 23, 29, 30}; // 4
			//int [] lottoryNum = {2, 27, 28, 31, 39, 41};  // 4
			//int [] lottoryNum = {15, 16, 33, 34, 43, 49}; // 4
			//int [] lottoryNum = {6, 18, 33, 34, 47, 49}; // 4
			//int [] lottoryNum = {14, 17, 24, 26, 28, 43}; // 4
			//int [] lottoryNum = {11, 18, 27, 37, 40, 49}; // 4
			//int [] lottoryNum = {1, 3, 24, 27, 32, 36}; // 4 

			//int [] lottoryNum = {1, 3, 24, 27, 32, 36}; // 4 => 01,03,24,32
			//int [] lottoryNum = {1, 6, 22, 23, 29, 30}; // 4 => 01,06,29,30   06,23,29,30
			//int [] lottoryNum = {2, 7, 9, 19, 43, 44}; // 4 => 02,07,19,44
			//int [] lottoryNum = {2, 27, 28, 31, 39, 41};  // 4 => 27,28,31,41   27,28,39,41
			//int [] lottoryNum = {3, 4, 6, 15, 17, 39};  // 4 => 03,04,06,17   03,04,15,39   03,04,17,39   03,15,17,39
			//int [] lottoryNum = {6, 18, 33, 34, 47, 49}; // 4 => 06,18,33,34    33,34,47,49
			//int [] lottoryNum = {6, 19, 22, 25, 39, 42}; // 3
			//int [] lottoryNum = {11, 18, 27, 37, 40, 49}; // 4 => 11,27,40,49
			//int [] lottoryNum = {14, 17, 24, 26, 28, 43}; // 4 => 17,26,28,43
			//int [] lottoryNum = {15, 16, 33, 34, 43, 49}; // 4 => 15,16,34,49   15,33,34,49    16,33,43,49 
			
			int [] lottoryNum = {1, 30, 34, 35, 38, 42};
			String[] checked = printNum(lottoryNum).split("\n");
			
			Connection c = null;
			Statement stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    String sql = "";
		    
		    PrintWriter printWriter = null;

		    try {

		        printWriter = new PrintWriter("lotto649_Check_" + lottoryNum[0] + "_" + lottoryNum[1] + "_" + lottoryNum[2] + "_" + lottoryNum[3] + "_" + lottoryNum[4] + "_" + lottoryNum[5] + ".txt");

		    	int lastIndex = 0;
			    for (int i=0; i<checked.length; i++)
			    {
			    	sql = "select * from L649_COUNT where L_VALUE='" + checked[i] + "';";
			    	ResultSet rs = stmt.executeQuery(sql);
			    	if (!rs.isClosed())
			    	{
			    		int count = Integer.valueOf(rs.getString("L_COUNT"));
		    			printWriter.println(checked[i] + " => " + count);
		    			lastIndex = i;
			    	}
			    	rs.close();
			    }
			    if (lastIndex < 6)
			    	lastIndex = 1;
			    else if (lastIndex < 21)
			    	lastIndex = 2;
			    else if (lastIndex < 41)
			    	lastIndex = 3;
			    else if (lastIndex < 56)
			    	lastIndex = 4;
			    else if (lastIndex < 62)
			    	lastIndex = 5;
			    else
			    	lastIndex = 6;
			    printWriter.println("Max matched number : " + lastIndex);
			    printWriter.close();	
		    } catch (FileNotFoundException error) {
		        error.printStackTrace();
		    } finally {
		    	if (printWriter!=null)
		    		printWriter.close();
		    }
		    
		    System.out.println("Done");
   
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
