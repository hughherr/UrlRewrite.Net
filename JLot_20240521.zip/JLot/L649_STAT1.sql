select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N5 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N2||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
union
select * from L649_COUNT where L_VALUE in 
( 
SELECT L_N1||','||L_N2||','||L_N3||','||L_N4||','||L_N5||','||L_N6 from L649_GUESS 
)
