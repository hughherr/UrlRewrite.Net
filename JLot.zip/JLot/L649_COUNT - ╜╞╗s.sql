CREATE TABLE `L649_COUNT` ( `L_SELECT` INTEGER, `L_VALUE` TEXT, `L_COUNT` INTEGER )

select * from 
(
select L_N1, L_N2, L_N3, L_N4, L_N5, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N3, L_N4, L_N5
) a where CNT > 1

INSERT INTO L649_COUNT
select 1 as L_SELECT, LN as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as LN, count(*) as CNT from L539_NUMBER group by L_N1
union all
select L_N2 as LN, count(*) as CNT from L539_NUMBER group by L_N2
union all
select L_N3 as LN, count(*) as CNT from L539_NUMBER group by L_N3
union all
select L_N4 as LN, count(*) as CNT from L539_NUMBER group by L_N4
union all
select L_N5 as LN, count(*) as CNT from L539_NUMBER group by L_N5
) a group by L_VALUE order by L_COUNT 

select * from L539_NUMBER where L_N1='29' or L_N2='29'



INSERT INTO L539_COUNT
select 2 as L_SELECT, L_N1 || ',' || L_N2 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, count(*) as CNT from L539_NUMBER group by L_N1, L_N2
union all
select L_N1 as L_N1, L_N3 as L_N2, count(*) as CNT from L539_NUMBER group by L_N1, L_N3
union all
select L_N1 as L_N1, L_N4 as L_N2, count(*) as CNT from L539_NUMBER group by L_N1, L_N4
union all
select L_N1 as L_N1, L_N5 as L_N2, count(*) as CNT from L539_NUMBER group by L_N1, L_N5
union all
select L_N2 as L_N1, L_N3 as L_N2, count(*) as CNT from L539_NUMBER group by L_N2, L_N3
union all
select L_N2 as L_N1, L_N4 as L_N2, count(*) as CNT from L539_NUMBER group by L_N2, L_N4
union all
select L_N2 as L_N1, L_N5 as L_N2, count(*) as CNT from L539_NUMBER group by L_N2, L_N5
union all
select L_N3 as L_N1, L_N4 as L_N2, count(*) as CNT from L539_NUMBER group by L_N3, L_N4
union all
select L_N3 as L_N1, L_N5 as L_N2, count(*) as CNT from L539_NUMBER group by L_N3, L_N5
union all
select L_N4 as L_N1, L_N5 as L_N2, count(*) as CNT from L539_NUMBER group by L_N4, L_N5
) a group by as L_VALUE order by L_COUNT




INSERT INTO L539_COUNT
select 3 as L_SELECT, L_N1 || ',' || L_N2 || ',' || L_N3 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N3
union all
select L_N1 as L_N1, L_N2 as L_N2, L_N4 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N4
union all
select L_N1 as L_N1, L_N2 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N5
union all
select L_N1 as L_N1, L_N3 as L_N2, L_N4 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N3, L_N4
union all
select L_N1 as L_N1, L_N3 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N3, L_N5
union all
select L_N1 as L_N1, L_N4 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N1, L_N4, L_N5
union all
select L_N2 as L_N1, L_N3 as L_N2, L_N4 as L_N3, count(*) as CNT from L539_NUMBER group by L_N2, L_N3, L_N4
union all
select L_N2 as L_N1, L_N3 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N2, L_N3, L_N5
union all
select L_N2 as L_N1, L_N4 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N2, L_N4, L_N5
union all
select L_N3 as L_N1, L_N4 as L_N2, L_N5 as L_N3, count(*) as CNT from L539_NUMBER group by L_N3, L_N4, L_N5
) a group by L_VALUE order by L_COUNT





INSERT INTO L539_COUNT
select 4 as L_SELECT, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, L_N4 as L_N4, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N3, L_N4
union all
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, L_N5 as L_N4, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N3, L_N5
union all
select L_N1 as L_N1, L_N2 as L_N2, L_N4 as L_N3, L_N5 as L_N4, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N4, L_N5
union all
select L_N1 as L_N1, L_N3 as L_N2, L_N4 as L_N3, L_N5 as L_N4, count(*) as CNT from L539_NUMBER group by L_N1, L_N3, L_N4, L_N5
union all
select L_N2 as L_N1, L_N3 as L_N2, L_N4 as L_N3, L_N5 as L_N4, count(*) as CNT from L539_NUMBER group by L_N2, L_N3, L_N4, L_N5
) a group by L_VALUE order by L_COUNT





INSERT INTO L539_COUNT
select 5 as L_SELECT, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 || ',' || L_N5 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, L_N4 as L_N4, L_N5 as L_N5, count(*) as CNT from L539_NUMBER group by L_N1, L_N2, L_N3, L_N4, L_N5
) a group by L_VALUE order by L_COUNT

08,23,24,28,30
select max(L_COUNT) from L539_COUNT WHERE L_SELECT=1 -- 229
select min(L_COUNT) from L539_COUNT WHERE L_SELECT=1 -- 175
select L_COUNT from L539_COUNT WHERE L_VALUE='08' -- 190
select L_COUNT from L539_COUNT WHERE L_VALUE='23' -- 206
select L_COUNT from L539_COUNT WHERE L_VALUE='24' -- 192
select L_COUNT from L539_COUNT WHERE L_VALUE='28' -- 215
select L_COUNT from L539_COUNT WHERE L_VALUE='30' -- 175


select max(L_COUNT) from L539_COUNT WHERE L_SELECT=2 -- 37
select min(L_COUNT) from L539_COUNT WHERE L_SELECT=2 -- 7
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23' -- 20
select L_COUNT from L539_COUNT WHERE L_VALUE='08,24' -- 25
select L_COUNT from L539_COUNT WHERE L_VALUE='08,28' -- 19
select L_COUNT from L539_COUNT WHERE L_VALUE='08,30' -- 13
select L_COUNT from L539_COUNT WHERE L_VALUE='23,24' -- 20
select L_COUNT from L539_COUNT WHERE L_VALUE='23,28' -- 18
select L_COUNT from L539_COUNT WHERE L_VALUE='23,30' -- 16
select L_COUNT from L539_COUNT WHERE L_VALUE='24,28' -- 30
select L_COUNT from L539_COUNT WHERE L_VALUE='24,30' -- 17
select L_COUNT from L539_COUNT WHERE L_VALUE='28,30' -- 15


select max(L_COUNT) from L539_COUNT WHERE L_SELECT=3 -- 8
select min(L_COUNT) from L539_COUNT WHERE L_SELECT=3 -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,24' -- 6
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,28' -- 2
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,24,28' -- 3
select L_COUNT from L539_COUNT WHERE L_VALUE='08,24,30' -- 3
select L_COUNT from L539_COUNT WHERE L_VALUE='08,28,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='23,24,28' -- 3
select L_COUNT from L539_COUNT WHERE L_VALUE='23,24,30' -- 2
select L_COUNT from L539_COUNT WHERE L_VALUE='23,28,30' -- 2
select L_COUNT from L539_COUNT WHERE L_VALUE='24,28,30' -- 2



select max(L_COUNT) from L539_COUNT WHERE L_SELECT=4 -- 3
select min(L_COUNT) from L539_COUNT WHERE L_SELECT=4 -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,24,28' -- 6
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,24,30' -- 2
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,28,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,24,28,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='23,24,28,30' -- 3



select max(L_COUNT) from L539_COUNT WHERE L_SELECT=5 -- 2
select min(L_COUNT) from L539_COUNT WHERE L_SELECT=5 -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,24,28' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,24,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,23,28,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='08,24,28,30' -- 1
select L_COUNT from L539_COUNT WHERE L_VALUE='23,24,28,30' -- 1
