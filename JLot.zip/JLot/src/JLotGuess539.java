import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;  
import java.io.File;  

public class JLotGuess539 {
	
	public static String printNum(int [] number)
	{
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<number.length; i++)
		{
			sb.append(String.format("%02d\n", number[i]));
		}

		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				if (i<j)
					sb.append(String.format("%02d,%02d\n", number[i], number[j]));
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					if (i<j && j < k)
						sb.append(String.format("%02d,%02d,%02d\n", number[i], number[j], number[k]));
				}
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					for (int p=0; p<number.length; p++)
					{
						if (i<j && j < k && k<p)
							sb.append(String.format("%02d,%02d,%02d,%02d\n", number[i], number[j], number[k], number[p]));
					}
				}
			}
		}			
		sb.append(String.format("%02d,%02d,%02d,%02d,%02d", number[0], number[1], number[2], number[3], number[4]));
		return(sb.toString());
	}
	
	public static void main( String args[] )
	{
		try {
			int [] lottoryNum = {1, 11, 23, 38, 39};
			String[] checked = printNum(lottoryNum).split("\n");
			
			Connection c = null;
			Statement stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    String sql = "";
		    for (int i=0; i<checked.length; i++)
		    {
		    	sql = "select * from L539_COUNT where L_VALUE='" + checked[i] + "';";
		    	ResultSet rs = stmt.executeQuery(sql);
		    	if (!rs.isClosed())
		    		System.out.println(checked[i] + " => " + rs.getString("L_COUNT"));
		    	else
		    		System.out.println(checked[i] + " => " + 0);
		    	rs.close();
		    }
	        
	        try   
	        {  
	        	//creating a constructor of file class and parsing an XML file  
	        	File file = new File("./L539_COUNT.xml");  
	        	//an instance of factory that gives a document builder  
	        	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
	        	//an instance of builder to parse the specified xml file  
	        	DocumentBuilder db = dbf.newDocumentBuilder();  
	        	Document doc = db.parse(file);  
	        	doc.getDocumentElement().normalize();  
	        	//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
	        	NodeList nodeList = doc.getElementsByTagName("SQLContent");  
	        	// nodeList is not iterable, so we are using for loop  
	        	for (int itr = 0; itr < nodeList.getLength(); itr++)   
	        	{  
	        		Node node = nodeList.item(itr);  
	        		System.out.println("\nNode Name :" + node.getNodeName());  
	        		if (node.getNodeType() == Node.ELEMENT_NODE)   
	        		{  
	        			sql = node.getTextContent();  
	        			System.out.println(sql);
	        			stmt.executeUpdate(sql);  
	        		}  
	        	}  
	        }   
	        catch (Exception e)   
	        {  
	        	e.printStackTrace();  
	        }  
	        //stmt.executeUpdate(sql);
	        stmt.close();
		    c.commit();
		    c.close();
		    System.out.println("Done");
   
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
