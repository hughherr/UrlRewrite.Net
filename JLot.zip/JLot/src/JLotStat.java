import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class JLotStat {
	public static void main( String args[] )
	{
		try {
			Connection c = null;
			Statement stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    String sql = "select * from L649_NUMBER where L_SEQNO>='0002' and L_SEQNO<='0008';";
		    HashMap<String, String> lotnum = new HashMap<String, String>();
		    for (int i=1; i<=49; i++)
		    {
		    	lotnum.put(String.format("%02d", i), String.format("%02d", i));
		    }
	        ResultSet rs = stmt.executeQuery(sql);
	        //STEP 5: Extract data from result set
	        while(rs.next()){
	           //Retrieve by column name
	        	lotnum.remove(rs.getString("L_N1"));
	        	lotnum.remove(rs.getString("L_N2"));
	        	lotnum.remove(rs.getString("L_N3"));
	        	lotnum.remove(rs.getString("L_N4"));
	        	lotnum.remove(rs.getString("L_N5"));
	        	lotnum.remove(rs.getString("L_N6"));
	        	lotnum.remove(rs.getString("L_N7"));
	        }
	        rs.close();			
			
	        // Getting a Set of Key-value pairs
	        Set entrySet = lotnum.entrySet();
	     
	        // Obtaining an iterator for the entry set
	        Iterator it = entrySet.iterator();
	     
	        // Iterate through HashMap entries(Key-Value pairs)
	        System.out.println("HashMap Key-Value Pairs : ");
	        while(it.hasNext()){
	           Map.Entry me = (Map.Entry)it.next();
	           System.out.println("Key is: "+me.getKey() + 
	           " & " + 
	           " value is: "+me.getValue());
	       }	        
		} catch (Exception ex) {
			
		}
	}
}
