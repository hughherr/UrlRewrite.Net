import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;  
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;  

public class JLotGuess649 {
	
	public static String printNum(int [] number)
	{
		StringBuffer sb = new StringBuffer();
		for (int i=0; i<number.length; i++)
		{
			sb.append(String.format("%02d\n", number[i]));
		}

		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				if (i<j)
					sb.append(String.format("%02d,%02d\n", number[i], number[j]));
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					if (i<j && j < k)
						sb.append(String.format("%02d,%02d,%02d\n", number[i], number[j], number[k]));
				}
			}
		}
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					for (int p=0; p<number.length; p++)
					{
						if (i<j && j < k && k<p)
							sb.append(String.format("%02d,%02d,%02d,%02d\n", number[i], number[j], number[k], number[p]));
					}
				}
			}
		}			
		
		for (int i=0; i<number.length; i++)
		{
			for (int j=0; j<number.length; j++)
			{
				for (int k=0; k<number.length; k++)
				{
					for (int p=0; p<number.length; p++)
					{
						for (int q=0; q<number.length; q++)
						{
							if (i<j && j < k && k<p && p<q)
								sb.append(String.format("%02d,%02d,%02d,%02d,%02d\n", number[i], number[j], number[k], number[p], number[q]));
						}				
					}
				}
			}
		}	
		
		sb.append(String.format("%02d,%02d,%02d,%02d,%02d,%02d", number[0], number[1], number[2], number[3], number[4], number[5]));
		return(sb.toString());
	}
	
	public static void main( String args[] )
	{
		try {
			//int [] lottoryNum = {1, 2, 6, 7, 27, 38};
			int [] lottoryNum = {7, 18, 28 , 30, 34, 35};
			//String[] checked = printNum(lottoryNum).split("\n");
			
			Connection c = null;
			Statement stmt = null;
			Class.forName("org.sqlite.JDBC");
			c = DriverManager.getConnection("jdbc:sqlite:JLot.db");
			c.setAutoCommit(false);
			System.out.println("Opened database successfully");
		    stmt = c.createStatement();
		    String sql = "";
		    
		    PrintWriter printWriter = null;

		    try {
		    	for (int k=1; k<=1; k++)
		    	{
			    	sql = "select * from L649_NUMBER_BASE where L_SEQNO='" + String.format("%04d", k) + "';";
			    	ResultSet rsno = stmt.executeQuery(sql);
			    	if (!rsno.isClosed())
			    	{
			    		//for (int j = 1; j <= 6; j++)
			    		//	lottoryNum[j-1] =  Integer.valueOf(rsno.getString("L_N" + Integer.toString(j)));
			    		String[] checked = printNum(lottoryNum).split("\n");
			    		
				        printWriter = new PrintWriter("lotto649_" + String.format("%04d", k) + ".txt");
		
				    	int lastIndex = 0;
					    for (int i=0; i<checked.length; i++)
					    {
					    	sql = "select * from L649_COUNT where L_VALUE='" + checked[i] + "';";
					    	ResultSet rs = stmt.executeQuery(sql);
					    	if (!rs.isClosed())
					    	{
					    		int count = Integer.valueOf(rs.getString("L_COUNT"));
					    		if (count > 1)
					    		{
					    			//System.out.println(checked[i] + " => " + (count - 1));
					    			printWriter.println(checked[i] + " => " + (count - 1));
					    			lastIndex = i;
					    		}
					    	//else
					    	//	System.out.println(checked[i] + " => " + 0);
					    	}
					    	rs.close();
					    }
					    if (lastIndex < 6)
					    	lastIndex = 1;
					    else if (lastIndex < 21)
					    	lastIndex = 2;
					    else if (lastIndex < 41)
					    	lastIndex = 3;
					    else if (lastIndex < 56)
					    	lastIndex = 4;
					    else if (lastIndex < 62)
					    	lastIndex = 5;
					    else
					    	lastIndex = 6;
					    printWriter.close();	
					    System.out.println(String.format("%04d", k) + "=>" + lastIndex);
			    	}
		    	}
		    } catch (FileNotFoundException error) {
		        error.printStackTrace();
		    } finally {
		    	if (printWriter!=null)
		    		printWriter.close();
		    }
		    

	        
	        try   
	        {  
	        	//creating a constructor of file class and parsing an XML file  
	        	File file = new File("./L539_COUNT.xml");  
	        	//an instance of factory that gives a document builder  
	        	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
	        	//an instance of builder to parse the specified xml file  
	        	DocumentBuilder db = dbf.newDocumentBuilder();  
	        	Document doc = db.parse(file);  
	        	doc.getDocumentElement().normalize();  
	        	//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
	        	NodeList nodeList = doc.getElementsByTagName("SQLContent");  
	        	// nodeList is not iterable, so we are using for loop  
	        	for (int itr = 0; itr < nodeList.getLength(); itr++)   
	        	{  
	        		Node node = nodeList.item(itr);  
	        		System.out.println("\nNode Name :" + node.getNodeName());  
	        		if (node.getNodeType() == Node.ELEMENT_NODE)   
	        		{  
	        			sql = node.getTextContent();  
	        			System.out.println(sql);
	        			stmt.executeUpdate(sql);  
	        		}  
	        	}  
	        }   
	        catch (Exception e)   
	        {  
	        	e.printStackTrace();  
	        }  
	        //stmt.executeUpdate(sql);
	        stmt.close();
		    c.commit();
		    c.close();
		    System.out.println("Done");
   
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
