INSERT INTO L4star_COUNT
select 1 as L_SELECT, LN as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as LN, count(*) as CNT from L4star_NUMBER group by L_N1
union all
select L_N2 as LN, count(*) as CNT from L4star_NUMBER group by L_N2
union all
select L_N3 as LN, count(*) as CNT from L4star_NUMBER group by L_N3
union all
select L_N4 as LN, count(*) as CNT from L4star_NUMBER group by L_N4
) a group by L_VALUE order by L_COUNT 

----------

INSERT INTO L649_COUNT
select "1+" as L_SELECT, LN as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N7 as LN, count(*) as CNT from L649_NUMBER group by L_N7
) a group by L_VALUE order by L_COUNT 

----------

INSERT INTO L4star_COUNT
select 2 as L_SELECT, L_N1 || ',' || L_N2 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N1, L_N2
union all
select L_N1 as L_N1, L_N3 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N1, L_N3
union all
select L_N1 as L_N1, L_N4 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N1, L_N4
union all
select L_N2 as L_N1, L_N3 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N2, L_N3
union all
select L_N2 as L_N1, L_N4 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N2, L_N4
union all
select L_N3 as L_N1, L_N4 as L_N2, count(*) as CNT from L4star_NUMBER group by L_N3, L_N4
) a group by L_VALUE order by L_COUNT

----------

INSERT INTO L4star_COUNT
select 3 as L_SELECT, L_N1 || ',' || L_N2 || ',' || L_N3 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, count(*) as CNT from L4star_NUMBER group by L_N1, L_N2, L_N3
union all
select L_N1 as L_N1, L_N2 as L_N2, L_N4 as L_N3, count(*) as CNT from L4star_NUMBER group by L_N1, L_N2, L_N4
union all
select L_N1 as L_N1, L_N3 as L_N2, L_N4 as L_N3, count(*) as CNT from L4star_NUMBER group by L_N1, L_N3, L_N4
union all
select L_N2 as L_N1, L_N3 as L_N2, L_N4 as L_N3, count(*) as CNT from L4star_NUMBER group by L_N2, L_N3, L_N4
) a group by L_VALUE order by L_COUNT

----------

INSERT INTO L4star_COUNT
select 4 as L_SELECT, L_N1 || ',' || L_N2 || ',' || L_N3 || ',' || L_N4 as L_VALUE, sum(CNT) as L_COUNT from
(
select L_N1 as L_N1, L_N2 as L_N2, L_N3 as L_N3, L_N4 as L_N4, count(*) as CNT from L4star_NUMBER group by L_N1, L_N2, L_N3, L_N4
) a group by L_VALUE order by L_COUNT

----------


SELECT * FROM L649_COUNT WHERE L_SELECT=6 and L_COUNT > 1 -- 0
SELECT * FROM L649_COUNT WHERE L_SELECT=5 and L_COUNT > 1 -- 0
