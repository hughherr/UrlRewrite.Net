﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FluentFTP.Proxy.Enums {
	internal enum SocksVersion {
		V4 = 0x04,
		V5 = 0x05
	}
}
