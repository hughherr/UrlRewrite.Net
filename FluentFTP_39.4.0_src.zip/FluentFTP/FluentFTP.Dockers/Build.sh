
sudo docker build proftpd -t proftpd:fluentftp

sudo docker build pureftpd -t pureftpd:fluentftp

sudo docker build vsftpd -t vsftpd:fluentftp

sudo docker build pyftpdlib -t pyftpdlib:fluentftp
